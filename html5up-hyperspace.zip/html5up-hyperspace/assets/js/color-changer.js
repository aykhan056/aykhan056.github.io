// Color changer script - applies saved color across all pages
(function() {
	// Color conversion utilities
	function hexToRgb(hex) {
		const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
		return result ? {
			r: parseInt(result[1], 16),
			g: parseInt(result[2], 16),
			b: parseInt(result[3], 16)
		} : null;
	}

	function rgbToHex(r, g, b) {
		return "#" + [r, g, b].map(x => {
			const hex = x.toString(16);
			return hex.length === 1 ? "0" + hex : hex;
		}).join("");
	}

	function lightenColor(hex, percent) {
		const rgb = hexToRgb(hex);
		if (!rgb) return hex;
		const r = Math.min(255, Math.round(rgb.r + (255 - rgb.r) * percent));
		const g = Math.min(255, Math.round(rgb.g + (255 - rgb.g) * percent));
		const b = Math.min(255, Math.round(rgb.b + (255 - rgb.b) * percent));
		return rgbToHex(r, g, b);
	}

	function darkenColor(hex, percent) {
		const rgb = hexToRgb(hex);
		if (!rgb) return hex;
		const r = Math.max(0, Math.round(rgb.r * (1 - percent)));
		const g = Math.max(0, Math.round(rgb.g * (1 - percent)));
		const b = Math.max(0, Math.round(rgb.b * (1 - percent)));
		return rgbToHex(r, g, b);
	}

	window.applyColor = function(primaryColor) {
		// Generate color shades
		const color1 = primaryColor; // Primary accent
		const color2 = darkenColor(primaryColor, 0.15); // Darker shade
		const color3 = darkenColor(primaryColor, 0.3); // Base background
		const color4 = lightenColor(primaryColor, 0.15); // Lighter shade
		const color5 = darkenColor(primaryColor, 0.45); // Darkest shade

		// Update CSS
		const style = document.createElement('style');
		style.id = 'dynamic-colors';
		
		// Remove existing dynamic color styles
		const existing = document.getElementById('dynamic-colors');
		if (existing) existing.remove();

		style.textContent = `
			body { background: ${color3} !important; }
			#sidebar { background: ${color3} !important; }
			.wrapper.style1 { background-color: ${color1} !important; }
			.wrapper.style1-alt { background-color: ${color2} !important; }
			.wrapper.style2 { background-color: ${color2} !important; }
			.wrapper.style2-alt { background-color: ${color3} !important; }
			.wrapper.style3 { background-color: ${color4} !important; }
			.wrapper.style3-alt { background-color: ${color1} !important; }
			.wrapper.alt { background-color: ${color5} !important; }
			#sidebar nav a:before { background: ${color5} !important; }
			#sidebar nav a:after {
				background-image: -moz-linear-gradient(to right, ${color1}, ${color4}) !important;
				background-image: -webkit-linear-gradient(to right, ${color1}, ${color4}) !important;
				background-image: -ms-linear-gradient(to right, ${color1}, ${color4}) !important;
				background-image: linear-gradient(to right, ${color1}, ${color4}) !important;
			}
			@media screen and (max-width: 1280px) {
				#sidebar nav a:after {
					background-color: ${color4} !important;
				}
			}
			.wrapper.style1 .icon.major:before { color: ${color1} !important; }
			.wrapper.style1-alt .icon.major:before { color: ${color2} !important; }
			.wrapper.style2 .icon.major:before { color: ${color2} !important; }
			.wrapper.style2-alt .icon.major:before { color: ${color3} !important; }
			.wrapper.style3 .icon.major:before { color: ${color4} !important; }
			.wrapper.style3-alt .icon.major:before { color: ${color1} !important; }
			.icon.major { color: ${color3} !important; }
			input[type="checkbox"]:checked + label:before,
			input[type="radio"]:checked + label:before { color: ${color4} !important; }
			#header { background-color: ${color1} !important; }
			.button.primary:after { background-color: ${color1} !important; }
		`;

		document.head.appendChild(style);
	};

	// Load saved color on page load
	window.addEventListener('load', function() {
		const savedColor = localStorage.getItem('primaryColor');
		if (savedColor) {
			window.applyColor(savedColor);
		}
	});
})();

